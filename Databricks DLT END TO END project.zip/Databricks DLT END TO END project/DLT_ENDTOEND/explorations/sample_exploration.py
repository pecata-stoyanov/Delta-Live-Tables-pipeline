# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT * FROM databrickspepi.gold.products_silver
# MAGIC WHERE product_id = 29

# COMMAND ----------

